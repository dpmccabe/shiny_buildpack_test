#' Generic plot scaling methods
#'
#' @docType package
#' @name package-scales
#' @aliases scales package-scales
#' @useDynLib scales
#' @importFrom plyr round_any is.discrete
#' @importFrom Rcpp evalCpp
NULL
